@echo off
cd /d "%~dp0"
call npm install
if errorlevel 1 goto fail
call npm run dist
if errorlevel 1 goto fail
echo.
echo Done. Installer is in the dist folder.
pause
exit /b 0
:fail
echo Build failed. Check the messages above.
pause
exit /b 1
