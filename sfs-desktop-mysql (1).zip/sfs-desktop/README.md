# SFS Accounting: Windows desktop app with MySQL

Electron desktop app. The window talks to a small built-in Node server, which stores everything in MySQL.
Login passwords are hashed with bcrypt on the server.

## 1. What you need
- **MySQL 5.7 or 8** (or MariaDB 10.3+), installed and running. Easy options: MySQL Installer for Windows, or XAMPP.
- To BUILD the .exe: **Node.js 18 or newer** on a Windows PC, with internet access.
- To only USE the finished installer: nothing except MySQL.

## 2. Build the .exe (on Windows)
Double-click `build-windows.bat`, or in a terminal in this folder:

    npm install
    npm run dist

The installer appears in `dist\SFS Accounting Setup 1.0.0.exe`. Install it and open "SFS Accounting".
To try it without installing: `npm start`.

## 3. First start
1. A "database setup" page opens. Enter the MySQL host (localhost), port (3306), user and password, and a database
   name (sfs_accounting). The app creates the database and all tables for you.
2. Create the admin account, then fill in Business Profile (logo and details).
3. The connection details are saved in `%APPDATA%\sfs-accounting\config.json`. Delete that file to set up again.

## 4. Several PCs on one database (optional)
Run on the PC that has MySQL:  `npm run server`  (or `node server-cli.js`).
Other PCs open `http://<that-pc-ip>:3000` in a browser (allow port 3000 in Windows Firewall).
Everyone signs in with their own account. Use it on a trusted network, or put HTTPS in front of it.

## 5. Tables created
users, settings, meta, accounts, customers, suppliers, items, invoices, bills, doc_lines, payments, expenses,
journals, saved_reports. See `schema.sql`. Back up with mysqldump, or Settings > Download backup in the app.

## 6. How it works and its limits (please read)
- The app saves by sending the full data set; the server only rewrites tables that changed. This suits small and
  medium businesses (thousands of records), not very large ones.
- Two people editing at once: each save carries a revision number. If someone else saved first, you get a message
  and the latest data loads, so you repeat your last change. The screen also refreshes itself every 15 seconds.
- Enforced on the SERVER: sign-in, session expiry (12 h), admin-only user management and settings, and
  chart-of-accounts changes only for allowed roles.
- Enforced only in the APP SCREEN: the per-module rights (view / create / delete). Someone technical with a valid
  login could bypass those. Real per-module enforcement needs per-record server endpoints.
- Money columns are DECIMAL; the on-screen maths uses normal floating point and shows 2 decimals.
- PDF and Excel libraries load from the internet. For offline PCs put jspdf.umd.min.js and xlsx.full.min.js in
  `public\vendor\`.
- Not tested against a live MySQL server in the environment where this was written (only against a simulated one).
  Expect to fix small things on first real run.
