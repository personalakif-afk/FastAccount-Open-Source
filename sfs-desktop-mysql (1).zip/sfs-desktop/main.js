const {app,BrowserWindow,Menu,shell,dialog}=require('electron'),path=require('path'),{startServer}=require('./server');
let win;
async function createWindow(){
  let port;try{port=await startServer(app.getPath('userData'),3000,'127.0.0.1')}catch(e){dialog.showErrorBox('SFS Accounting','Could not start the app: '+e.message);app.quit();return}
  win=new BrowserWindow({width:1280,height:820,minWidth:900,minHeight:600,title:'SFS Accounting',icon:path.join(__dirname,'public/icons/icon-512.png'),webPreferences:{contextIsolation:true,nodeIntegration:false}});
  Menu.setApplicationMenu(null);win.loadURL('http://127.0.0.1:'+port+'/');
  win.webContents.setWindowOpenHandler(({url})=>{shell.openExternal(url);return{action:'deny'}});
}
app.whenReady().then(createWindow);app.on('window-all-closed',()=>app.quit());
