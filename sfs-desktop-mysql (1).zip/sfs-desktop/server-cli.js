// Server-only mode: run on one PC; other PCs open http://<this-pc-ip>:3000 in a browser.
const path=require('path'),{startServer}=require('./server');
startServer(path.join(__dirname,'data'),+process.env.PORT||3000,process.env.HOST||'0.0.0.0').then(p=>console.log('SFS Accounting running on http://localhost:'+p)).catch(e=>{console.error(e.message);process.exit(1)});
