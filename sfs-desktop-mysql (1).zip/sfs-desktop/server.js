'use strict';
const express=require('express'),path=require('path'),fs=require('fs'),crypto=require('crypto'),mysql=require('mysql2/promise'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken');
const COA=[['1000','Bank & Cash','A'],['1100','Accounts Receivable','A'],['1200','Input Tax','A'],['1300','Inventory','A'],['2000','Accounts Payable','L'],['2100','Tax Payable','L'],['3000','Owner Equity','Q'],['4000','Sales Revenue','I'],['5000','Cost of Goods Sold','X'],['6000','General Expenses','X'],['6100','Rent','X'],['6200','Salaries','X'],['6300','Utilities','X']];
const ROLES=new Set(['admin','manager','accountant','cashier','viewer','user']);
const MODS=['dashboard','pos','invoices','bills','payments','customers','suppliers','items','expenses','journals','coa','reports'];
const H=x=>crypto.createHash('sha1').update(JSON.stringify(x)).digest('hex');
const COLS={customers:'id,name,email,phone,address,walkin',suppliers:'id,name,email,phone,address',items:'id,name,sku,price,cost,qty',invoices:'id,no,party,doc_date,due,tax,pos',bills:'id,no,party,doc_date,due,tax',doc_lines:'doc_type,doc_id,line_no,item,descr,qty,price,cost',payments:'id,kind,doc,doc_no,pay_date,amount,method',expenses:'id,exp_date,payee,acc,amount',journals:'id,jdate,memo,dr,cr,amount',saved_reports:'id,name,cfg',accounts:'code,name,type'};

function createApp(dataDir){
  const cfgPath=path.join(dataDir,'config.json');let cfg=null,pool=null;const cache={};
  try{cfg=JSON.parse(fs.readFileSync(cfgPath,'utf8'))}catch(e){cfg=null}
  const mkPool=d=>mysql.createPool({host:d.host,port:+d.port||3306,user:d.user,password:d.password,database:d.database,waitForConnections:true,connectionLimit:10,decimalNumbers:true,dateStrings:true,charset:'utf8mb4'});
  if(cfg&&cfg.db)pool=mkPool(cfg.db);
  const app=express(),pub=path.join(__dirname,'public');
  app.disable('x-powered-by');app.use(express.json({limit:'25mb'}));
  app.get(['/','/index.html'],(req,res)=>cfg?res.sendFile(path.join(pub,'index.html')):res.redirect('/setup.html'));
  app.use(express.static(pub,{index:false}));
  const need=(req,res,next)=>cfg&&pool?next():res.status(503).json({error:'Database is not configured'});
  const pu=r=>({id:Number(r.id),name:r.name,email:r.email,role:r.role,perms:r.perms?JSON.parse(r.perms):null});
  const auth=async(req,res,next)=>{try{const t=(req.headers.authorization||'').replace(/^Bearer /,''),p=jwt.verify(t,cfg.secret),[r]=await pool.query('SELECT id,name,email,role,perms FROM users WHERE id=?',[p.uid]);if(!r.length)return res.status(401).json({error:'Session expired. Please sign in again.'});req.user=pu(r[0]);next()}catch(e){res.status(401).json({error:'Please sign in again.'})}};
  const adminOnly=(req,res,next)=>req.user.role==='admin'?next():res.status(403).json({error:'Admin only'});
  const token=id=>jwt.sign({uid:Number(id)},cfg.secret,{expiresIn:'12h'});
  const fails=new Map(),limited=k=>{const f=fails.get(k);return f&&f.n>=8&&Date.now()-f.t<9e5},bad=k=>{const f=fails.get(k),ok=f&&Date.now()-f.t<9e5;fails.set(k,{n:(ok?f.n:0)+1,t:Date.now()})};

  // ---- first-run MySQL setup ----
  app.post('/setup/save',async(req,res)=>{
    if(cfg)return res.status(403).json({error:'Already configured. Delete config.json to configure again.'});
    const b=req.body||{},dbn=String(b.database||'').trim();
    if(!/^[A-Za-z0-9_]{1,60}$/.test(dbn))return res.status(400).json({error:'Database name: letters, numbers and underscore only.'});
    const d={host:String(b.host||'localhost').trim(),port:+b.port||3306,user:String(b.user||'').trim(),password:String(b.password||''),database:dbn};
    let conn;
    try{
      conn=await mysql.createConnection({host:d.host,port:d.port,user:d.user,password:d.password,multipleStatements:false});
      await conn.query('CREATE DATABASE IF NOT EXISTS `'+dbn+'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
      await conn.query('USE `'+dbn+'`');
      for(const st of fs.readFileSync(path.join(__dirname,'schema.sql'),'utf8').split(/;\s*\n/).map(x=>x.trim()).filter(Boolean))await conn.query(st);
      const [c]=await conn.query('SELECT COUNT(*) n FROM accounts');if(!c[0].n)await conn.query('INSERT INTO accounts(code,name,type) VALUES ?',[COA]);
      await conn.query("INSERT IGNORE INTO meta(k,v) VALUES ('rev',1),('seq',1)");
    }catch(e){return res.status(400).json({error:'MySQL error: '+(e.sqlMessage||e.message)})}
    finally{if(conn)await conn.end().catch(()=>{})}
    cfg={db:d,secret:crypto.randomBytes(32).toString('hex')};fs.mkdirSync(dataDir,{recursive:true});fs.writeFileSync(cfgPath,JSON.stringify(cfg,null,2));pool=mkPool(d);res.json({ok:true});
  });

  // ---- public status (branding for the sign-in screen) ----
  app.get('/api/status',async(req,res)=>{
    if(!cfg||!pool)return res.json({configured:false});
    try{const [u]=await pool.query('SELECT COUNT(*) n FROM users'),[s]=await pool.query("SELECT k,v FROM settings WHERE k IN ('co','logo','color','lw','lh')"),set={};s.forEach(r=>{try{set[r.k]=JSON.parse(r.v)}catch(e){}});res.json({configured:true,first:u[0].n==0,set})}
    catch(e){res.status(500).json({error:'Cannot connect to MySQL ('+(e.code||e.message)+'). Is MySQL running? To change the connection, delete config.json in '+dataDir})}
  });

  // ---- auth ----
  app.post('/api/register-first',need,async(req,res)=>{
    const b=req.body||{},name=String(b.name||'').trim().slice(0,150),email=String(b.email||'').trim().toLowerCase(),pw=String(b.password||'');
    if(!name||!/^\S+@\S+\.\S+$/.test(email)||pw.length<8)return res.status(400).json({error:'Enter a name, a valid email and a password of at least 8 characters.'});
    try{const [u]=await pool.query('SELECT COUNT(*) n FROM users');if(u[0].n>0)return res.status(403).json({error:'An admin account already exists. Sign in instead.'});
      const id=1;await pool.query('INSERT INTO users(id,name,email,role,pass_hash) VALUES (?,?,?,?,?)',[id,name,email,'admin',await bcrypt.hash(pw,10)]);res.json({token:token(id)})}
    catch(e){res.status(500).json({error:'Database error: '+(e.sqlMessage||e.message)})}
  });
  app.post('/api/login',need,async(req,res)=>{
    const b=req.body||{},email=String(b.email||'').trim().toLowerCase(),key=req.ip+'|'+email;
    if(limited(key))return res.status(429).json({error:'Too many attempts. Try again in 15 minutes.'});
    try{const [r]=await pool.query('SELECT id,pass_hash FROM users WHERE email=?',[email]);
      if(!r.length||!(await bcrypt.compare(String(b.password||''),r[0].pass_hash))){bad(key);return res.status(401).json({error:'Wrong email or password'})}
      fails.delete(key);res.json({token:token(r[0].id)})}
    catch(e){res.status(500).json({error:'Database error: '+(e.sqlMessage||e.message)})}
  });

  // ---- data ----
  async function readState(user){
    const q=async(s,p)=>(await pool.query(s,p))[0],adm=user.role==='admin';
    const [cust,sup,items,inv,bills,lines,pays,exps,jr,coa,reps,sets,meta,us]=await Promise.all([q('SELECT * FROM customers ORDER BY id'),q('SELECT * FROM suppliers ORDER BY id'),q('SELECT * FROM items ORDER BY id'),q('SELECT * FROM invoices ORDER BY id'),q('SELECT * FROM bills ORDER BY id'),q('SELECT * FROM doc_lines ORDER BY doc_type,doc_id,line_no'),q('SELECT * FROM payments ORDER BY id'),q('SELECT * FROM expenses ORDER BY id'),q('SELECT * FROM journals ORDER BY id'),q('SELECT * FROM accounts ORDER BY code'),q('SELECT * FROM saved_reports ORDER BY id'),q('SELECT * FROM settings'),q('SELECT * FROM meta'),q(adm?'SELECT id,name,email,role,perms FROM users ORDER BY id':'SELECT id,name,email,role,perms FROM users WHERE id=?',adm?undefined:[user.id])]);
    const L={I:{},B:{}};lines.forEach(l=>(L[l.doc_type][l.doc_id]=L[l.doc_type][l.doc_id]||[]).push({item:l.item==null?'':Number(l.item),desc:l.descr||'',qty:l.qty,price:l.price,cost:l.cost}));
    const party=r=>({id:Number(r.id),name:r.name,email:r.email||'',phone:r.phone||'',address:r.address||''});
    const mk=(r,t)=>{const d={id:Number(r.id),no:r.no,party:Number(r.party),date:r.doc_date,due:r.due,tax:r.tax,lines:L[t][r.id]||[]};if(t==='I'&&r.pos)d.pos=true;return d};
    const set={};sets.forEach(r=>{try{set[r.k]=JSON.parse(r.v)}catch(e){}});const mt={};meta.forEach(r=>mt[r.k]=Number(r.v));
    return{rev:mt.rev||1,state:{customers:cust.map(r=>({...party(r),...(r.walkin?{walkin:true}:{})})),suppliers:sup.map(party),items:items.map(r=>({id:Number(r.id),name:r.name,sku:r.sku||'',price:r.price,cost:r.cost,qty:r.qty})),invoices:inv.map(r=>mk(r,'I')),bills:bills.map(r=>mk(r,'B')),payments:pays.map(r=>({id:Number(r.id),kind:r.kind,doc:Number(r.doc),docNo:r.doc_no||'',date:r.pay_date,amount:r.amount,method:r.method||''})),expenses:exps.map(r=>({id:Number(r.id),date:r.exp_date,payee:r.payee||'',acc:r.acc,amount:r.amount})),journals:jr.map(r=>({id:Number(r.id),date:r.jdate,memo:r.memo||'',dr:r.dr,cr:r.cr,amount:r.amount})),coa:coa.map(r=>({code:r.code,name:r.name,type:r.type})),reports:reps.map(r=>({id:Number(r.id),name:r.name,cfg:JSON.parse(r.cfg||'{}')})),set,seq:mt.seq||1,users:us.map(pu)}};
  }
  async function writeState(conn,st,user,rev){
    const [mr]=await conn.query("SELECT v FROM meta WHERE k='rev' FOR UPDATE");
    if(Number(mr[0].v)!==Number(rev))throw Object.assign(new Error('Data was changed by another user.'),{status:409});
    const today=new Date().toISOString().slice(0,10),D=x=>/^\d{4}-\d{2}-\d{2}$/.test(String(x))?String(x):today,N=(x,d=0)=>{x=Number(x);return isFinite(x)?x:d},S=(x,n=255)=>String(x==null?'':x).slice(0,n),I=x=>{x=Math.trunc(Number(x));return x>0?x:0},rows=(a,fn)=>(Array.isArray(a)?a:[]).map(fn).filter(Boolean);
    const T={};
    T.customers=rows(st.customers,r=>I(r.id)&&[I(r.id),S(r.name,190),S(r.email,190),S(r.phone,60),S(r.address,2000),r.walkin?1:0]);
    T.suppliers=rows(st.suppliers,r=>I(r.id)&&[I(r.id),S(r.name,190),S(r.email,190),S(r.phone,60),S(r.address,2000)]);
    T.items=rows(st.items,r=>I(r.id)&&[I(r.id),S(r.name,190),S(r.sku,60),N(r.price),N(r.cost),N(r.qty)]);
    T.invoices=rows(st.invoices,r=>I(r.id)&&[I(r.id),S(r.no,30),I(r.party),D(r.date),D(r.due),N(r.tax),r.pos?1:0]);
    T.bills=rows(st.bills,r=>I(r.id)&&[I(r.id),S(r.no,30),I(r.party),D(r.date),D(r.due),N(r.tax)]);
    T.doc_lines=[];[['I',st.invoices],['B',st.bills]].forEach(([t,a])=>(Array.isArray(a)?a:[]).forEach(d=>I(d.id)&&(d.lines||[]).forEach((l,i)=>T.doc_lines.push([t,I(d.id),i,l.item===''||l.item==null?null:(I(l.item)||null),S(l.desc,255),N(l.qty),N(l.price),N(l.cost)]))));
    T.payments=rows(st.payments,r=>I(r.id)&&[I(r.id),S(r.kind,3),I(r.doc),S(r.docNo,30),D(r.date),N(r.amount),S(r.method,30)]);
    T.expenses=rows(st.expenses,r=>I(r.id)&&[I(r.id),D(r.date),S(r.payee),S(r.acc,10),N(r.amount)]);
    T.journals=rows(st.journals,r=>I(r.id)&&[I(r.id),D(r.date),S(r.memo),S(r.dr,10),S(r.cr,10),N(r.amount)]);
    T.saved_reports=rows(st.reports,r=>I(r.id)&&[I(r.id),S(r.name,150),JSON.stringify(r.cfg||{})]);
    const adm=user.role==='admin',canCoa=adm||user.role==='manager'||user.role==='accountant'||(user.perms&&user.perms.coa>=2);
    if(canCoa&&Array.isArray(st.coa)&&st.coa.length)T.accounts=rows(st.coa,r=>/^\d{3,6}$/.test(String(r.code))&&/^[AILQX]$/.test(r.type)&&[String(r.code),S(r.name,150),r.type]);
    const nh={};
    for(const t in T){const h=H(T[t]);nh[t]=h;if(cache[t]===h)continue;await conn.query('DELETE FROM '+t);for(let i=0;i<T[t].length;i+=500)await conn.query('INSERT INTO '+t+' ('+COLS[t]+') VALUES ?',[T[t].slice(i,i+500)])}
    if(adm&&st.set&&typeof st.set==='object'){const rs=Object.entries(st.set).filter(([k])=>/^[a-z]{1,20}$/.test(k)).map(([k,v])=>[k,JSON.stringify(v)]),h=H(rs);if(cache.settings!==h){await conn.query('DELETE FROM settings');if(rs.length)await conn.query('INSERT INTO settings(k,v) VALUES ?',[rs]);nh.settings=h}}
    await conn.query("UPDATE meta SET v=v+1 WHERE k='rev'");await conn.query("UPDATE meta SET v=GREATEST(v,?) WHERE k='seq'",[Math.max(1,I(st.seq))]);
    return{rev:Number(mr[0].v)+1,nh};
  }
  app.get('/api/state',need,auth,async(req,res)=>{try{const r=await readState(req.user);res.json({state:r.state,rev:r.rev,me:req.user.id})}catch(e){res.status(500).json({error:'Database error: '+(e.sqlMessage||e.message)})}});
  app.get('/api/rev',need,auth,async(req,res)=>{try{const [r]=await pool.query("SELECT v FROM meta WHERE k='rev'");res.json({rev:Number(r[0].v)})}catch(e){res.status(500).json({error:'Database error'})}});
  app.put('/api/state',need,auth,async(req,res)=>{
    const conn=await pool.getConnection();
    try{await conn.beginTransaction();const r=await writeState(conn,(req.body||{}).state||{},req.user,(req.body||{}).rev);await conn.commit();Object.assign(cache,r.nh);res.json({rev:r.rev})}
    catch(e){await conn.rollback().catch(()=>{});res.status(e.status||500).json({error:e.status===409?e.message:'Database error: '+(e.sqlMessage||e.message)})}
    finally{conn.release()}
  });

  // ---- users (admin) ----
  app.post('/api/users',need,auth,adminOnly,async(req,res)=>{
    const b=req.body||{},name=String(b.name||'').trim().slice(0,150),email=String(b.email||'').trim().toLowerCase(),role=b.role,pw=b.password?String(b.password):'',E=(c,m)=>res.status(c).json({error:m});
    if(!name||!/^\S+@\S+\.\S+$/.test(email))return E(400,'Enter a name and a valid email.');if(!ROLES.has(role))return E(400,'Unknown role.');if(pw&&pw.length<8)return E(400,'Password must be at least 8 characters.');
    let perms=null;if(role!=='admin'&&b.perms&&typeof b.perms==='object'){perms={};MODS.forEach(m=>perms[m]=Math.max(0,Math.min(3,Math.trunc(Number(b.perms[m])||0))))}
    try{
      const id=Number(b.id)||0,[dup]=await pool.query('SELECT id FROM users WHERE email=? AND id<>?',[email,id]);if(dup.length)return E(400,'That email is already in use.');
      if(id){const [r]=await pool.query('SELECT id,role FROM users WHERE id=?',[id]);if(!r.length)return E(404,'User not found.');
        if(r[0].role==='admin'&&role!=='admin'){const [a]=await pool.query("SELECT COUNT(*) n FROM users WHERE role='admin'");if(a[0].n<2)return E(400,'Keep at least one admin.');if(id===req.user.id)return E(400,'You cannot demote yourself.')}
        await pool.query('UPDATE users SET name=?,email=?,role=?,perms=? WHERE id=?',[name,email,role,perms?JSON.stringify(perms):null,id]);if(pw)await pool.query('UPDATE users SET pass_hash=? WHERE id=?',[await bcrypt.hash(pw,10),id])}
      else{if(!pw)return E(400,'A password of at least 8 characters is required.');const [m]=await pool.query('SELECT COALESCE(MAX(id),0)+1 n FROM users');await pool.query('INSERT INTO users(id,name,email,role,pass_hash,perms) VALUES (?,?,?,?,?,?)',[m[0].n,name,email,role,await bcrypt.hash(pw,10),perms?JSON.stringify(perms):null])}
      res.json({ok:true});
    }catch(e){E(500,'Database error: '+(e.sqlMessage||e.message))}
  });
  app.delete('/api/users/:id',need,auth,adminOnly,async(req,res)=>{
    const id=Number(req.params.id),E=(c,m)=>res.status(c).json({error:m});if(id===req.user.id)return E(400,'You cannot delete yourself.');
    try{const [r]=await pool.query('SELECT role FROM users WHERE id=?',[id]);if(!r.length)return E(404,'User not found.');if(r[0].role==='admin'){const [a]=await pool.query("SELECT COUNT(*) n FROM users WHERE role='admin'");if(a[0].n<2)return E(400,'Keep at least one admin.')}
      await pool.query('DELETE FROM users WHERE id=?',[id]);res.json({ok:true})}catch(e){E(500,'Database error')}
  });
  return app;
}
function startServer(dataDir,port=3000,host='127.0.0.1'){
  const app=createApp(dataDir);
  return new Promise((ok,no)=>{const s=app.listen(port,host);s.once('listening',()=>ok(s.address().port));s.once('error',e=>{if(e.code==='EADDRINUSE'){const s2=app.listen(0,host);s2.once('listening',()=>ok(s2.address().port));s2.once('error',no)}else no(e)})});
}
module.exports={startServer};
